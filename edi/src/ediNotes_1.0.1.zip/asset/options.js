jQuery(document).ready(function($){
	$('#getSummaryBox').click(getSummaryBox);
	$('#getSummaryBoxText').click(getSummaryBox);
	$('#getSettingBox').click(getSettingBox);
	$('#getSettingBoxText').click(getSettingBox);
});