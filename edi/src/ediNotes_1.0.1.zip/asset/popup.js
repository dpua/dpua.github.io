	function newNote(){
		chrome.extension.getBackgroundPage().newNote();
	}
	
	function loadNotes()
	{
		chrome.extension.getBackgroundPage().loadNotes();
	}

	
	